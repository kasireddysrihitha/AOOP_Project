import java.util.Objects;

public final class Product {
    private final String sku, name;
    private final Money price;
    private final Percentage discount;
    public Product(String sku, String name, Money price, Percentage discount) {
        if (sku == null || sku.trim().isEmpty() || name == null || name.trim().isEmpty())
            throw new IllegalArgumentException("SKU and name cannot be blank");
        this.sku = sku.trim();
        this.name = name.trim();
        this.price = Objects.requireNonNull(price);
        this.discount = Objects.requireNonNull(discount);
    }
    public String getSku() { return sku; }
    public String getName() { return name; }
    public Money getPrice() { return price; }
    public Percentage getDiscount() { return discount; }
    public Money getDiscountedPrice() { return discount.applyTo(price); }
    @Override public boolean equals(Object o) { return o instanceof Product && sku.equals(((Product)o).sku); }
    @Override public int hashCode() { return sku.hashCode(); }
    @Override public String toString() { return name + " (" + sku + ")"; }
}
