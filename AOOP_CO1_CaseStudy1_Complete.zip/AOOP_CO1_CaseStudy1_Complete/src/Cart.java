import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class Cart {
    private final String cartId;
    private final List<CartLine> items = new ArrayList<>();
    private Currency currency;
    public Cart(String cartId) {
        if (cartId == null || cartId.trim().isEmpty()) throw new IllegalArgumentException("Cart ID cannot be blank");
        this.cartId = cartId.trim();
    }
    public String getCartId() { return cartId; }
    public void addProduct(Product product, Quantity quantity) {
        if (product == null || quantity == null) throw new IllegalArgumentException("Product and quantity are required");
        Currency candidate = product.getPrice().getCurrency();
        if (currency != null && currency != candidate)
            throw new IllegalArgumentException("Currency mismatch");
        currency = candidate;
        items.add(new CartLine(product, quantity));
    }
    public List<CartLine> getItems() { return Collections.unmodifiableList(items); }
    public Money getTotal() {
        if (currency == null) return Money.zero(Currency.USD);
        Money total = Money.zero(currency);
        for (CartLine line : items) total = total.plus(line.getLineTotal());
        return total;
    }
}
