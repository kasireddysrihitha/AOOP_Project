import java.math.BigDecimal;
import java.util.Objects;

public final class Percentage {
    private final BigDecimal value;
    public Percentage(BigDecimal value) {
        Objects.requireNonNull(value);
        if (value.signum() < 0 || value.compareTo(new BigDecimal("100")) > 0)
            throw new IllegalArgumentException("Percentage must be between 0 and 100");
        this.value = value.stripTrailingZeros();
    }
    public static Percentage of(String value) { return new Percentage(new BigDecimal(value)); }
    public BigDecimal getValue() { return value; }
    public Money applyTo(Money money) { return Objects.requireNonNull(money).minus(this); }
    @Override public boolean equals(Object o) {
        return o instanceof Percentage && value.compareTo(((Percentage)o).value) == 0;
    }
    @Override public int hashCode() { return value.hashCode(); }
    @Override public String toString() { return value.toPlainString() + "%"; }
}
