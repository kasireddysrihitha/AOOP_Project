public class App {
    public static void main(String[] args) {
        Product laptop = new Product("P101", "Laptop",
            Money.of("1200.00", Currency.USD), Percentage.of("10"));
        Product mouse = new Product("P102", "Wireless Mouse",
            Money.of("25.00", Currency.USD), Percentage.of("5"));

        Cart cart = new Cart("C001");
        cart.addProduct(laptop, new Quantity(2));
        cart.addProduct(mouse, new Quantity(1));

        System.out.println("=== E-Commerce Catalog ===");
        System.out.println(laptop + " | Original: " + laptop.getPrice()
            + " | Discounted: " + laptop.getDiscountedPrice());
        System.out.println(mouse + " | Original: " + mouse.getPrice()
            + " | Discounted: " + mouse.getDiscountedPrice());

        System.out.println("\n=== Cart ===");
        System.out.println("Cart ID: " + cart.getCartId());
        for (CartLine line : cart.getItems()) System.out.println(line);
        System.out.println("Cart Total: " + cart.getTotal());

        System.out.println("\n=== Validation demonstrations ===");
        try {
            Money.of("5.00", Currency.USD).plus(Money.of("5.00", Currency.EUR));
        } catch (IllegalArgumentException ex) {
            System.out.println("Mixed currency rejected: " + ex.getMessage());
        }
        try {
            new Quantity(0);
        } catch (IllegalArgumentException ex) {
            System.out.println("Invalid quantity rejected: " + ex.getMessage());
        }
        try {
            Percentage.of("120");
        } catch (IllegalArgumentException ex) {
            System.out.println("Invalid discount rejected: " + ex.getMessage());
        }
    }
}
