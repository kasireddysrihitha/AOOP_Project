import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Objects;

public final class Money {
    private final BigDecimal amount;
    private final Currency currency;

    private Money(BigDecimal amount, Currency currency) {
        this.currency = Objects.requireNonNull(currency);
        Objects.requireNonNull(amount);
        if (amount.signum() < 0) throw new IllegalArgumentException("Money amount cannot be negative");
        try {
            this.amount = amount.setScale(currency.getMinorUnits(), RoundingMode.UNNECESSARY);
        } catch (ArithmeticException ex) {
            throw new IllegalArgumentException("Too many decimal places for " + currency, ex);
        }
    }

    public static Money of(String amount, Currency currency) {
        return new Money(new BigDecimal(amount), currency);
    }
    public static Money zero(Currency currency) { return new Money(BigDecimal.ZERO, currency); }
    public BigDecimal getAmount() { return amount; }
    public Currency getCurrency() { return currency; }

    public Money plus(Money other) {
        requireSameCurrency(other);
        return new Money(amount.add(other.amount), currency);
    }
    public Money times(Quantity quantity) {
        Objects.requireNonNull(quantity);
        return new Money(amount.multiply(BigDecimal.valueOf(quantity.getValue())), currency);
    }
    public Money minus(Percentage discount) {
        Objects.requireNonNull(discount);
        BigDecimal factor = BigDecimal.ONE.subtract(discount.getValue().movePointLeft(2));
        BigDecimal result = amount.multiply(factor)
            .setScale(currency.getMinorUnits(), RoundingMode.HALF_EVEN);
        return new Money(result, currency);
    }
    private void requireSameCurrency(Money other) {
        Objects.requireNonNull(other);
        if (currency != other.currency) throw new IllegalArgumentException("Currency mismatch");
    }
    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Money)) return false;
        Money m = (Money)o;
        return currency == m.currency && amount.compareTo(m.amount) == 0;
    }
    @Override public int hashCode() { return Objects.hash(amount.stripTrailingZeros(), currency); }
    @Override public String toString() { return currency + " " + amount.toPlainString(); }
}
