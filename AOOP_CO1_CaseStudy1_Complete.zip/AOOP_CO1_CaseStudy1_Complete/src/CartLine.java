import java.util.Objects;

public final class CartLine {
    private final Product product;
    private final Quantity quantity;
    public CartLine(Product product, Quantity quantity) {
        this.product = Objects.requireNonNull(product);
        this.quantity = Objects.requireNonNull(quantity);
    }
    public Product getProduct() { return product; }
    public Quantity getQuantity() { return quantity; }
    public Money getLineTotal() { return product.getDiscountedPrice().times(quantity); }
    @Override public String toString() {
        return product.getName() + " x " + quantity + " = " + getLineTotal();
    }
}
