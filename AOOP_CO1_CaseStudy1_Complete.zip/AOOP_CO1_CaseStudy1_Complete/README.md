# AOOP CO1 Case Study 1
## Money and Pricing in an E-Commerce Catalog

### Overview
A Java implementation of an e-commerce pricing model using immutable value objects and domain entities.

### Classes
- `Currency`: supported currencies and decimal precision.
- `Money`: non-negative monetary amount, currency-safe addition, quantity multiplication, and HALF_EVEN discount rounding.
- `Percentage`: validates a discount from 0% through 100% and applies it to `Money`.
- `Quantity`: positive whole-number quantity.
- `Product`: entity identified by SKU.
- `CartLine`: product plus quantity, with a calculated line total.
- `Cart`: aggregate root that prevents mixed currencies.
- `App`: executable demonstration of pricing, discounts, cart totals, and invalid-input handling.

### Design decisions
1. `BigDecimal` is used instead of `double` to avoid binary floating-point errors.
2. Each currency defines its supported decimal precision.
3. Money values are immutable and cannot be negative.
4. Money addition requires matching currencies. No implicit currency conversion occurs.
5. Discounts are constrained to 0..100 inclusive.
6. Discount results are rounded using `HALF_EVEN` at the currency's minor-unit precision.
7. Quantity must be a positive integer.
8. Product equality is based on SKU.

### Compile and run (JDK 17+)
```powershell
javac -d bin src\*.java
java -cp bin App
```
